#include<stdio.h>
int main()
{
	int i,sum=0;
	for(i=3;i<=20;i+=3)
	{
		sum+=i;
	}
	printf("%3d",sum);
	
	return 0;
}
