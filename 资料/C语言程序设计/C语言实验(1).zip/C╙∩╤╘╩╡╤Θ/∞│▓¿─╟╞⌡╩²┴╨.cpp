#include <stdio.h>
int main()
{
    int i;
	int Fib[20]={1,1};
    for(i=2;i<20;i++)
     Fib[i]=Fib[i-2]+Fib[i-1];
    for(i=0;i<20;i++)
    {
    	if(i%5==0)
    	  printf("\n");
    	printf("%12d",Fib[i]);
    }
	return 0;
}
