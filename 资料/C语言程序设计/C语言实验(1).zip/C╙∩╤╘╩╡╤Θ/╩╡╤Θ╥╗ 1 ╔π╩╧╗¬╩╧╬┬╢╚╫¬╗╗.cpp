#include <stdio.h>
int main( )
{
	int f;
	float c;
    scanf("%d��%d",&f,&c);
    c=5.0/9*(f-32);
    printf("c=%.1f\n",c);
    return 0;
}
