#include <stdio.h>
#include <math.h>
int main()
{
	double n=1,t=1,PI=0;
	int s=1;
	while(fabs(t)>=1e-8)
	{
		PI=PI+t;
		n=n+2;
		s=-s;
		t=s/n;
	}
	PI=PI*4;
	printf("PI=%7.5f\n",PI);
	return 0;
}
