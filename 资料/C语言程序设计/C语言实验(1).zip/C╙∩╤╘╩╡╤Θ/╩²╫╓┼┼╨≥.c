#include<stdio.h>
int main()
{
	int i,j,temp;
	int array[5]={5,4,2,3,1};
	for(i=0;i<5;i++)
	 for(j=0;j<5-i;j++)
	  if(array[j]>array[j+1])
	  {
	  	temp=array[j+1];
	  	array[j+1]=array[j];
	  	array[j]=temp;
	  }
	for(i=0;i<5;i++)
	  printf("%4d",array[i]);
	return 0;
}
