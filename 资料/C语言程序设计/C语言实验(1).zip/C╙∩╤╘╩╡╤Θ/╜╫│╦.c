#include<stdio.h>
int main()
{
	int n=1,i;
	for(i=1;i<=5;i++)
	{
		n*=i;
	} 
	printf("%d",n);
	return 0;
}
