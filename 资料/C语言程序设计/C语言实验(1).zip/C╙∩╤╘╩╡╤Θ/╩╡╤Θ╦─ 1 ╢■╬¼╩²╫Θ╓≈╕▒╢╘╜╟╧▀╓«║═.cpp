#include <stdio.h>
int main()
{
    int A[3][3]={1,2,3,4,5,6,9,8,7};
    int i,j,sum1=0,sum2=0;
    for(i=0;i<3;i++)
       for(j=0;j<3;j++)
       {
           if(i=j)
             sum1+=A[i][j];
           if(2==i+j)
             sum2+=A[i][j];
       }
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
          printf("%4d",A[i][j]);
        printf("\n");
    }
    printf("sum1=%d,sum2=%d\n",sum1,sum2);
    return 0;
}
