#include <stdio.h>
int main()
{
    int i,k;
    int A[10]={1,2,3,4,5,6,7,8,9,10};
    for(i=0;i<5;i++)
    {
        k=A[9-i];
        A[9-i]=A[i];
        A[i]=k;
    }
    for(i=0;i<10;i++) 
    printf("%3d",A[i]);
    return 0;
}
