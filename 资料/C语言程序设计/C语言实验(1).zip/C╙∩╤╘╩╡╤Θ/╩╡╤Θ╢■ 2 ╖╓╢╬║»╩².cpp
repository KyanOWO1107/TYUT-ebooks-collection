#include<stdio.h>
int main()
{
    int x,y;
    scanf("%d",&x);
    if(x<0)
        y=2*x-9;
    if(x==0)
        y=0;
    if(x>0&&x<10)
        y=x+1;
    if(x>=10)
        y=2*x+9;
    printf("y=%d\n",y);
    return 0;
}
