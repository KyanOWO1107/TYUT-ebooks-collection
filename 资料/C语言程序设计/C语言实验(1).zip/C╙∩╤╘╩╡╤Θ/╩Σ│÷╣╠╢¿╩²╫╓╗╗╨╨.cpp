#include <stdio.h>
int main()
{
	int n,i=0;
	for(n=50;n<=100;n++)
	{
		if(n%3!=0)
		{
			printf("%5d",n);
			i=i++;
			if(i%4==0)
			printf("\n");
		}
	}
	return 0;
}
