#include<stdio.h>
#include<string.h>
int main()
{
	int m,n,s,d;
	char c;
	m=n=s=d=0;
	while((c=getchar())!='\n')
	{
		if(c==' ')
		 m++;
		else if(c>='0'&&c<='9')
		 n++;
		else if(c>='a'&&c<='z'||c>='A'&&c<='Z')
		 s++;
		else 
		 d++;
	}
	printf("kongge=%d,shuzi=%d,zimu=%d,qita=%d",m,n,s,d);
	return 0;
}
